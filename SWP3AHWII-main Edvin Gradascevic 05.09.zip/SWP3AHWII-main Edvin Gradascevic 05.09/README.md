# SWP3AHWII

Material und Code zum Unterricht

## 2023-09-05

Hausübung: rechts neben dem clickme button ein textinputfield anlegen, dessen text bei Klick als
listeneintrag an die Liste angehängt wird.
